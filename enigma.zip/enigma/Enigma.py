import Plugboard
import Reflector
import Rotor


class Enigma:

    def __init__(self,leftRotor,midlleRotor,RightRotor,plugBoard,reflector):
        self.leftRotor = leftRotor
        self.midlleRotor = midlleRotor
        self.rightRotor = RightRotor
        self.plugBoard = plugBoard
        self.reflector = reflector

    def translate(self,tav):
        tav= tav.upper()
        translateTav = self.plugBoard.translate(tav)
        if self.rightRotor.rotorSpin():
            if self.midlleRotor.rotorSpin():
                self.leftRotor.rotorSpin()
        r1 = self.rightRotor.translate(translateTav)
        Tr = self.rightRotor.changeTav(r1)
        r2 =self.midlleRotor.translate(Tr)
        Tr2 = self.midlleRotor.changeTav(r2)
        r3 = self.leftRotor.translate(Tr2)
        Tr3 = self.leftRotor.changeTav(r3)
        #print(r1 ,Tr , r2,Tr2, r3,Tr3)
        #translateTav = self.leftRotor.translate(self.midlleRotor.translate(self.rightRotor.translate(translateTav)))
        #print(translateTav)
        translateTav = self.reflector.translateReflrctor(Tr3)
        #print(translateTav)
        Rt = self.leftRotor.changeT(translateTav)
        translateTav1 = self.leftRotor.reverseTranslate(Rt)
        Rt2 = self.midlleRotor.changeT(translateTav1)
        translateTav2 = self.midlleRotor.reverseTranslate(Rt2)
        Rt3 = self.rightRotor.changeT(translateTav2)
        translateTav3 = self.rightRotor.reverseTranslate(Rt3)

        #print(Rt,translateTav1,Rt2,translateTav2,Rt3,translateTav3)
        translateTav = self.plugBoard.translate(translateTav3)
        #print(translateTav)
        return translateTav

