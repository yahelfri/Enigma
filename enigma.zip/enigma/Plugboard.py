class plugboard:
    plugboardTupl = (("Z","U"), ("H","L"), ("C","Q"), ("W","M") ,("O","A"), ("P","Y"), ("E","B"), ("T","R"), ("D","N"), ("V","I"))

    def translate(self,tav):
        tav = tav.upper()
        for i in range(len(self.plugboardTupl)):
            if tav == self.plugboardTupl[i][0]:
                return self.plugboardTupl[i][1]
            elif tav == self.plugboardTupl[i][1]:
                return self.plugboardTupl[i][0]
        return tav



