class Rotor:
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

    rotor1 = "EKMFLGDQVZNTOWYHXUSPAIBRCJ"
    rotor1Notch = "Q"
    rotor2 = "AJDKSIRUXBLHWTMCQGZNPYFVOE"
    rotor2Notch = "E"
    rotor3 = "BDFHJLCPRTXVZNYEIWGAKMUSQO"
    rotor3Notch = "V"
    rotor4 = "ESOVPZJAYQUIRHXLNFTGKDCMWB"
    rotor4Notch = "J"
    rotor5 = "VZBRGITYUPSDNHLXAWMJQOFECK"
    rotor5Notch = "Z"
    rotorTupl = (rotor1,rotor2,rotor3,rotor4,rotor5)
    rotorNotchTupl = (rotor1Notch,rotor2Notch,rotor3Notch,rotor4Notch,rotor5Notch)
    def __init__(self, index, ringSeting,):
        index = index % 5
        self.rotorValues = self.rotorTupl[index]
        self.current_location = ringSeting.upper()
        self.rotorNotch = self.rotorNotchTupl[index]



    rotorDict = {"I": rotor1, "II": rotor2, "III": rotor3, "IV": rotor4, "V": rotor5}
    rotorNotchDict = {"I": rotor1Notch, "II": rotor2Notch, "III": rotor3Notch, "IV": rotor4Notch, "V": rotor5Notch}

    def rotorSpin(self):
        flag = False
        if (self.rotorNotch == self.current_location):
            flag = True
        self.current_location = self.alphabet[(self.alphabet.index(self.current_location) +1)%26]
        if(self.current_location==26):
            self.current_location = 0
        return flag

    def translate(self,tav):
        tav = tav.upper()
        index =  (self.alphabet.index(tav) + self.alphabet.index(self.current_location)) % 26
        x = self.rotorValues[index]
        return x

    def changeTav(self,tav):
        x = self.alphabet[(self.alphabet.index(tav) - self.alphabet.index(self.current_location)) % 26]
        return x
    def reverseTranslate(self,tav):
        index = self.rotorValues.index(tav)
        return self.alphabet[(index - self.alphabet.index(self.current_location))%26]

    def changeT(self,tav):
        x = self.alphabet[(self.alphabet.index(tav) + self.alphabet.index(self.current_location)) % 26]
        return x

    def setCurrentLocation(self,tav):
        self.current_location = tav