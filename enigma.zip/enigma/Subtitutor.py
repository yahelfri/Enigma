import Rotor
import Translator

def decryption():
    rr = 4
    rm = 5
    rl = 2
    '''input1 = "CON MLD UMPDQ CUAQN LVVSP"
    input2 = "CON MLD TTRJQ KCFPT OKRGO"
    input3 = "CON MLD RLPUH AUZSO SZFSU"
    input4 = "CON MLD DZCUG VEXUU LQYXO"
    input5 = "CON MLD SYGGZ HQMAG PZDKC"
    input6 = "CON MLD MYYDD H"
    strList = [input1,input2,input3,input4,input5,input6]'''
    input7 = "CON MLD UMPDQ CUAQN LVVSP TTRJQ KCFPT OKRGO RLPUH AUZSO SZFSU DZCUG VEXUU LQYXO SYGGZ HQMAG PZDKC MYYDD H"
    strList = input7.upper().split(" ")
    #for str in strList:
        #str = str.upper().split(" ")
    str = strList
    rotorr = Rotor.Rotor(rr - 1, str[0][2])
    rotorm = Rotor.Rotor(rm - 1, str[0][1])
    rotorl = Rotor.Rotor(rl - 1, str[0][0])
    trans = Translator.Translator(rotorr, rotorm, rotorl)
    setoff = trans.translat(str[1])
    '''
    rotorr2 = Rotor.Rotor(rr - 1, setoff[2])
    rotorm2 = Rotor.Rotor(rm - 1, setoff[1])
    rotorl2 = Rotor.Rotor(rl - 1, setoff[0])
    trans2 = Translator.Translator(rotorr2, rotorm2, rotorl2)
    str = str[2:]
    strr = " ".join(str)
    print(trans2.translat(strr))'''
    rotorr.setCurrentLocation(setoff[2])
    rotorm.setCurrentLocation(setoff[1])
    rotorl.setCurrentLocation(setoff[0])
    str = str[2:]
    strr = " ".join(str)
    print(trans.translat(strr))




decryption()