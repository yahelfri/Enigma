import Enigma
import Plugboard
import Reflector
import Rotor

class Translator:

    def __init__(self,rotorR,rotorM,rotorL):
        self.plugboard = Plugboard.plugboard()
        self.reflector = Reflector.Reflector()
        self.enigma = Enigma.Enigma(rotorL,rotorM,rotorR,self.plugboard,self.reflector)

    def translat(self,str):
        tav = ""
        strList = str.upper().split(" ")
        for word in strList:
            for j in range(len(word)):
                tav += self.enigma.translate(word[j])

            tav += " "

        return tav
